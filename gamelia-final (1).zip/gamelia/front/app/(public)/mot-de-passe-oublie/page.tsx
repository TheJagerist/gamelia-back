import type { Metadata } from 'next';
import Link from 'next/link';
import { LifeBuoy } from 'lucide-react';
import { AuthCard } from '@/components/auth-card';
import { CONTACT_EMAIL } from '@/lib/site';

export const metadata: Metadata = { title: 'Mot de passe oublié' };

// Le site n'envoie pas d'e-mail : pas de lien de réinitialisation automatique. L'équipe remplace le mot de
// passe à la main (commande `npm run reset-password` du back) après avoir vérifié l'identité du membre.
export default function ForgotPage() {
  const subject = encodeURIComponent('Gamelia : mot de passe oublié');
  return (
    <AuthCard title="Mot de passe oublié" subtitle="L'équipe Gamelia vous aide à retrouver l'accès à votre compte.">
      <div className="rounded-lg bg-primary-soft p-5">
        <LifeBuoy className="mb-2 h-6 w-6 text-primary" aria-hidden />
        <p className="font-semibold">Écrivez-nous depuis l&apos;adresse e-mail de votre compte.</p>
        <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm">
          <li>
            Envoyez un message à{' '}
            <a href={`mailto:${CONTACT_EMAIL}?subject=${subject}`} className="link break-all">
              {CONTACT_EMAIL}
            </a>{' '}
            en indiquant votre nom sur Gamelia.
          </li>
          <li>L&apos;équipe vérifie que la demande vient bien de vous, puis vous répond avec un mot de passe provisoire.</li>
          <li>Connectez-vous, puis choisissez votre propre mot de passe dans Paramètres, Mot de passe.</li>
        </ol>
        <p className="mt-3 text-sm text-muted">Gamelia n&apos;envoie pas d&apos;e-mail automatique : aucun lien ne vous sera envoyé sans que vous ayez écrit d&apos;abord.</p>
      </div>
      <Link href="/connexion" className="btn btn-secondary mt-5">
        Revenir à la connexion
      </Link>
    </AuthCard>
  );
}
