const express = require('express');
const bcrypt = require('bcryptjs');
const { z } = require('zod');
const { query, pool } = require('../db/pool');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const validate = require('../utils/validate');
const { requireUser } = require('../middleware/auth');
const { loadMe } = require('../utils/publicUser');
const { setSessionCookies, clearSessionCookies } = require('../utils/cookies');
const { createSession, generateUniqueUsername } = require('../utils/accounts');

const router = express.Router();

// --- GET /auth/me -----------------------------------------------------------
// attachSession (monté globalement dans server.js) a déjà rempli req.user si
// un cookie de session valide est présent ; sinon req.user est undefined.
router.get(
  '/me',
  asyncHandler(async (req, res) => {
    res.json(req.user ? await loadMe(req.user.id) : null);
  })
);

// --- POST /auth/inscription --------------------------------------------------
const inscriptionSchema = z
  .object({
    role: z.enum(['developpeur', 'recruteur']),
    name: z.string().trim().min(2, 'Le nom doit contenir au moins 2 caractères.').max(120, 'Le nom ne doit pas dépasser 120 caractères.'),
    email: z.string().trim().toLowerCase().max(254, 'Adresse e-mail invalide.').email('Adresse e-mail invalide.'),
    password: z.string().min(8, 'Le mot de passe doit contenir au moins 8 caractères.').max(128, 'Le mot de passe ne doit pas dépasser 128 caractères.'),
    country: z.string().trim().min(2, 'Le pays est requis.').max(60, 'Le pays est requis.'),
    company: z.string().trim().min(1).max(120, 'Le nom de l’entreprise ne doit pas dépasser 120 caractères.').optional(),
    // Case « J'accepte les conditions d'utilisation et la politique de confidentialité » : obligatoire.
    acceptTerms: z.any().refine((v) => v === true, { message: 'Vous devez accepter les conditions d’utilisation et la politique de confidentialité.' }),
  })
  .refine((d) => d.role !== 'recruteur' || !!d.company, {
    message: "Le nom de l'entreprise est requis pour un compte recruteur.",
    path: ['company'],
  });

router.post(
  '/inscription',
  asyncHandler(async (req, res) => {
    const data = validate(inscriptionSchema, req.body);

    const existing = await query('SELECT id FROM users WHERE email = $1', [data.email]);
    if (existing.rows.length > 0) {
      throw ApiError.conflict('Un compte existe déjà avec cette adresse e-mail.');
    }

    const username = await generateUniqueUsername(data.name);
    const passwordHash = await bcrypt.hash(data.password, 12);
    const recruiterStatus = data.role === 'recruteur' ? 'en_attente' : null;

    const inserted = await query(
      `INSERT INTO users (username, name, email, password_hash, role, country, company, recruiter_status, terms_accepted_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, now()) RETURNING *`,
      [username, data.name, data.email, passwordHash, data.role, data.country, data.company || null, recruiterStatus]
    );
    const user = inserted.rows[0];

    await query('INSERT INTO user_settings (user_id) VALUES ($1)', [user.id]);

    if (data.role === 'recruteur') {
      // Compte en attente : pas de session ouverte, on notifie les admins.
      await notifyAllAdmins(
        'validation',
        `${user.name} (${user.company}) a demandé un compte recruteur.`,
        '/admin/validations'
      );
      return res.status(201).json({ pending: true });
    }

    const session = await createSession(user.id, req.get('user-agent'));
    setSessionCookies(res, session.id, session.csrf_token);
    res.status(201).json(await loadMe(user.id));
  })
);

async function notifyAllAdmins(kind, text, href) {
  await query(
    `INSERT INTO notifications (user_id, kind, text, href)
     SELECT id, $1, $2, $3 FROM users WHERE role = 'admin'`,
    [kind, text, href]
  );
}

// --- POST /auth/connexion ----------------------------------------------------
const connexionSchema = z.object({
  email: z.string().trim().toLowerCase().max(254, 'Adresse e-mail invalide.').email('Adresse e-mail invalide.'),
  password: z.string().min(1, 'Le mot de passe est requis.').max(128, 'Adresse e-mail ou mot de passe incorrect.'),
});

router.post(
  '/connexion',
  asyncHandler(async (req, res) => {
    const data = validate(connexionSchema, req.body);

    const { rows } = await query('SELECT * FROM users WHERE email = $1', [data.email]);
    const user = rows[0];
    const ok = user && (await bcrypt.compare(data.password, user.password_hash));
    if (!ok) {
      // Message volontairement générique : ne pas révéler si l'email existe.
      throw ApiError.badRequest('Adresse e-mail ou mot de passe incorrect.');
    }

    if (user.role === 'recruteur' && user.recruiter_status !== 'valide') {
      throw ApiError.forbidden('Votre compte recruteur est en attente de validation par un administrateur.', 'recruteur_non_valide');
    }

    const session = await createSession(user.id, req.get('user-agent'));
    setSessionCookies(res, session.id, session.csrf_token);
    res.json(await loadMe(user.id));
  })
);

// --- POST /auth/deconnexion ---------------------------------------------------
router.post(
  '/deconnexion',
  requireUser,
  asyncHandler(async (req, res) => {
    await query('DELETE FROM sessions WHERE id = $1', [req.sessionId]);
    clearSessionCookies(res);
    res.status(204).end();
  })
);

// Pas de route « mot de passe oublié » : le site n'envoie aucun e-mail. Un membre qui a perdu son mot de
// passe écrit à l'équipe, qui vérifie son identité puis lance `npm run reset-password` sur le serveur.

// Connexion avec GitHub (OAuth) : /auth/github/etat, /start, /callback, /en-attente, /finaliser.
router.use('/github', require('./github-oauth'));

module.exports = router;
